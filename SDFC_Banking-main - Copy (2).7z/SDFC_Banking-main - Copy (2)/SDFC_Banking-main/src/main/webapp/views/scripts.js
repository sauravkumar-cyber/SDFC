
// Get all the navigation buttons
const navButtons = document.querySelectorAll('.nav-item.nav-link');

// Function to remove the 'active' class from all buttons
function removeActiveClass() {
    navButtons.forEach((btn) => {
        btn.classList.remove('active');
    });
}

// Add event listeners to each button
navButtons.forEach((button) => {
    // Add a click event listener to each button
    button.addEventListener('click', (event) => {
        // Remove the 'active' class from all buttons
        removeActiveClass();

        // Add the 'active' class to the clicked button
        button.classList.add('active');
    });

    // Add mouseover event listener to each button
    button.addEventListener('mouseover', (event) => {
        button.style.color = '#218b87'; 
    });

    // Add mouseout event listener to each button
    button.addEventListener('mouseout', (event) => {
        if (!button.classList.contains('active')) {
            button.style.color = 'white'; 
        }
    });
});



