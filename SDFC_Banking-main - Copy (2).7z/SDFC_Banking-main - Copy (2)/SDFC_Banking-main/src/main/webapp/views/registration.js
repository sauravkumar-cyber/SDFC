
        function validateForm() {
            const accno = document.getElementById('accno').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Check if account number contains exactly 10 digits
            const accnoPattern = /^\d{10}$/;
            if (!accnoPattern.test(accno)) {
                alert("Account number must be exactly 10 digits.");
                return false;
            }

            // Check if password and confirm password match
            if (password !== confirmPassword) {
                alert("Password and Confirm Password do not match.");
                return false;
            }

            // If all validations pass, submit the form
            alert("Form submitted successfully!");
            document.getElementById('registerForm').submit();
        }
    