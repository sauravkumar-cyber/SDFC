function validateLogin() {
    const accno = document.getElementById('accno').value;
    const name = document.getElementById('name').value;
    const password = document.getElementById('password').value;

    // Simulated user validation
    const validAccno = "1234567890";
    const validName = "Saurav";
    const validPassword = "123";

    if (accno === validAccno && name === validName && password === validPassword) {
        alert("Login successful!");
        window.location.href = "dashbord.html";
    } else {
        alert("Incorrect Account Number, Name, or Password.");
    }
}

