# SDFC Banking Application

## Overview

SDFC Banking Application is a complete web based and banking solution all the functions of a bank. The product has been developed using open, industry standard, proven technologies and high quality software engineering methodologies. SDFC Bank is highly parameterized to support constantly changing customer and regulatory requirement. The product truly leverages on web technologies and centralized database.

## Tech Used

HTML, CSS,JavaScript, MySQL, SpringBoot, JSP

## Modules

Savings Bank, New Account Opening, Deposit Fund, Withdrawal Fund, Transfer Fund, Close Account, Re-Open Account.

## Deployment

 1. HTML, CSS and JavaScript for client side validation.
 
 2. SpringBoot MVC for connecting database, mapping the JSP pages.

 3. JSP files for backend and frontend code.
 
 4. MySQL as a database.







